# Aarav & Meera — GitHub Pages wedding website

A static, bilingual (English/Hindi) Indian wedding invitation demo. It includes a countdown, event schedule, venue directions, animated decorative details, and an RSVP form that drafts a WhatsApp message.

## Publish on GitHub Pages

1. Sign in to GitHub and create a **new public repository** (for example, `wedding-invitation`). GitHub Free requires a public repository for GitHub Pages.
2. Open the new repository and choose **Add file → Upload files**.
3. Upload the contents of this folder directly (make sure `index.html`, `styles.css`, `app.js`, `.nojekyll`, and `README.md` are at the repository root, not inside another folder).
4. Commit the files to the `main` branch.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
7. Choose branch **main** and folder **/(root)**, then select **Save**.
8. Wait for the Pages deployment to complete. The published address will appear in **Settings → Pages**.

For a repository named `wedding-invitation`, the project site URL is usually:

`https://YOUR-GITHUB-USERNAME.github.io/wedding-invitation/`

## Customise before sharing

This is a demo invitation. Replace all sample names, family names, dates, times, venue details, dress codes and RSVP details before publishing.

- Edit visible couple, family, schedule and venue content in `index.html`.
- In `app.js`, update `WEDDING.ceremonyDate` with the correct date/time and India timezone offset, e.g. `2027-02-14T17:00:00+05:30`.
- In `app.js`, set `WEDDING.whatsappNumber` to the host's WhatsApp number with country code and digits only, e.g. `919876543210`.
- Check the Google Maps link in `index.html` and verify all details in both language modes.

The RSVP form opens WhatsApp with a pre-filled message; it does not save guest responses to a database. Do not put private guest lists or sensitive personal information in this public repository.

## Files

- `index.html` — page content and structure
- `styles.css` — responsive layout, visual styling and animations
- `app.js` — bilingual toggle, countdown and RSVP behavior
- `.nojekyll` — asks GitHub Pages to serve the static files without a Jekyll build

No Node.js, npm install, or build command is required.
