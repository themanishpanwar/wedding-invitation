/*
  QUICK CUSTOMISATION
  1) Edit couple names/date/venues in index.html.
  2) Edit the ceremony date and RSVP WhatsApp number below.
  3) If whatsappNumber is blank, WhatsApp opens with a pre-filled message and the guest chooses the recipient.
*/
const WEDDING = {
  ceremonyDate: '2027-02-14T17:00:00+05:30',
  whatsappNumber: '', // Example: '919876543210' (country code + number, no + or spaces)
  couple: 'Aarav & Meera'
};

const translations = {
  en: {
    skip:'Skip to content',brandCaption:'THE WEDDING CELEBRATION',navStory:'Our story',navEvents:'The celebrations',navVenue:'Venue',navRsvp:'RSVP',
    heroEyebrow:'WITH THE BLESSINGS OF OUR FAMILIES',heroInvoc:'शुभ विवाह',heroSubtitle:'Two hearts, one beautiful beginning.',heroCta:'EXPLORE THE CELEBRATIONS',scrollNote:'SCROLL TO FEEL THE JOY',
    welcomeKicker:'A NOTE FROM OUR FAMILIES',welcomeTitle:'With joy in our hearts,<br>we invite you to celebrate.',welcomeText:'Together with our families, we invite you to be part of the moments, the laughter, the traditions and the memories that will become our forever.',familyOne:'The Sharma Family',familyTwo:'The Mehta Family',
    countdownKicker:'THE BIG DAY IS ALMOST HERE',countdownTitle:'Counting down to forever',days:'DAYS',hours:'HOURS',minutes:'MINUTES',seconds:'SECONDS',
    storyKicker:'A LITTLE ABOUT US',storyScript:'A little magic, a lot of love',storyTitle:'Two paths, one destination.',storyText:'Somewhere between shared conversations, spontaneous smiles and the little things that became our favourite things, we found our person. Now, with our favourite people around us, we cannot wait to begin this next chapter.',storyLink:'Be part of our story',
    eventsKicker:'SAVE THE MOMENTS',eventsTitle:'The wedding festivities',eventsIntro:'A few days, a hundred memories, and all our favourite people.',haldiTitle:'Haldi & Blessings',haldiDesc:'A sunny afternoon of turmeric, laughter and family blessings.',haldiDress:'Yellow & marigold',mehendiTitle:'Mehendi & Sangeet',mehendiDesc:'Intricate henna, favourite songs and a dance floor full of joy.',mehendiDress:'Jewel tones & festive glam',weddingTitle:'The Wedding Ceremony',weddingDesc:'The moment we say yes to a lifetime of togetherness.',weddingDress:'Traditional Indian attire',receptionTitle:'Reception Evening',receptionDesc:'One more evening to dress up, raise a toast and celebrate.',receptionDress:'Formal & elegant',demoEvents:'Demo schedule — please replace the sample dates, timings and venues before sharing.',
    venueKicker:'MEET US IN JAIPUR',venueScript:'A place for beautiful memories',venueTitle:'The celebration awaits.',venueText:'Our celebrations are set in the heart of Jaipur, where warm hospitality and timeless architecture make every gathering feel special.',venueMap:'OPEN MAPS',
    rsvpKicker:'KINDLY REPLY',rsvpScript:'Your presence is our present',rsvpTitle:'Will you join us?',rsvpIntro:'Please let us know by 15 January 2027. We cannot wait to celebrate with you.',guestName:'Your name',guestPhone:'Mobile number',attendance:'Will you be celebrating with us?',accept:'Joyfully accepts',decline:'Regretfully declines',guestCount:'Number of guests',whichEvents:'Which celebrations will you attend?',eventHaldi:'Haldi',eventMehendi:'Mehendi & Sangeet',eventWedding:'Wedding',eventReception:'Reception',guestMessage:'A note for the couple (optional)',submitRsvp:'SEND YOUR RSVP',formNote:'This demo prepares your reply in WhatsApp. Add the couple’s number in app.js to send it directly.',
    closingTitle:'We cannot wait to celebrate with you.',closingText:'With love, Aarav & Meera and both our families.',footerText:'MADE WITH LOVE & A LITTLE BIT OF MAGIC'
  },
  hi: {
    skip:'मुख्य सामग्री पर जाएँ',brandCaption:'शुभ विवाह समारोह',navStory:'हमारी कहानी',navEvents:'शुभ अवसर',navVenue:'कार्यक्रम स्थल',navRsvp:'जवाब दें',
    heroEyebrow:'परिवारों के आशीर्वाद के साथ',heroInvoc:'शुभ विवाह',heroSubtitle:'दो दिल, एक खूबसूरत शुरुआत।',heroCta:'समारोह की झलक देखें',scrollNote:'खुशियों की ओर आगे बढ़ें',
    welcomeKicker:'परिवार की ओर से स्नेहिल निमंत्रण',welcomeTitle:'हृदय में हर्ष अपार,<br>आपका है सादर आमंत्रण।',welcomeText:'अपने परिवारों के साथ, हम आपको प्रेम, हँसी, परंपराओं और उन यादगार पलों का हिस्सा बनने के लिए आमंत्रित करते हैं, जिन्हें हम जीवनभर संजोएँगे।',familyOne:'शर्मा परिवार',familyTwo:'मेहता परिवार',
    countdownKicker:'शुभ दिन अब आने ही वाला है',countdownTitle:'नई शुरुआत की उलटी गिनती',days:'दिन',hours:'घंटे',minutes:'मिनट',seconds:'सेकंड',
    storyKicker:'हमारे बारे में',storyScript:'थोड़ा जादू, ढेर सारा प्यार',storyTitle:'दो राहें, अब एक मंज़िल।',storyText:'बातों, मुस्कुराहटों और छोटी-छोटी खुशियों के बीच हमें अपना हमसफ़र मिल गया। अब अपने प्रियजनों के साथ, हम जीवन के इस नए अध्याय की शुरुआत के लिए उत्साहित हैं।',storyLink:'हमारी कहानी का हिस्सा बनें',
    eventsKicker:'यादगार पलों के नाम',eventsTitle:'शादी के रंग और रस्में',eventsIntro:'कुछ दिन, ढेर सारी यादें और हमारे सभी अपने।',haldiTitle:'हल्दी एवं आशीर्वाद',haldiDesc:'हल्दी, हँसी और परिवार के आशीर्वाद से भरी सुनहरी दोपहर।',haldiDress:'पीला एवं गेंदे के रंग',mehendiTitle:'मेहंदी एवं संगीत',mehendiDesc:'खूबसूरत मेहंदी, पसंदीदा गीत और खुशियों से भरा डांस फ्लोर।',mehendiDress:'गहरे रंग एवं उत्सवी परिधान',weddingTitle:'शुभ विवाह समारोह',weddingDesc:'वह पल, जब हम जीवनभर साथ निभाने का वचन देंगे।',weddingDress:'पारंपरिक भारतीय परिधान',receptionTitle:'स्वागत समारोह',receptionDesc:'सजने-सँवरने, शुभकामनाएँ देने और जश्न मनाने की एक और शाम।',receptionDress:'औपचारिक एवं सुरुचिपूर्ण परिधान',demoEvents:'यह एक नमूना कार्यक्रम-सूची है। साझा करने से पहले तारीख़, समय और स्थान बदलें।',
    venueKicker:'जयपुर में मिलते हैं',venueScript:'यादों के नाम एक खूबसूरत जगह',venueTitle:'जश्न आपका इंतज़ार कर रहा है।',venueText:'हमारे समारोह जयपुर में होंगे, जहाँ मेहमाननवाज़ी और शाही स्थापत्य हर मुलाक़ात को ख़ास बना देंगे।',venueMap:'मैप खोलें',
    rsvpKicker:'कृपया अपनी उपस्थिति बताएँ',rsvpScript:'आपकी उपस्थिति ही हमारा उपहार है',rsvpTitle:'क्या आप साथ होंगे?',rsvpIntro:'कृपया 15 जनवरी 2027 तक हमें बताएँ। आपके साथ जश्न मनाने का इंतज़ार रहेगा।',guestName:'आपका नाम',guestPhone:'मोबाइल नंबर',attendance:'क्या आप हमारे साथ जश्न मनाएँगे?',accept:'हर्ष सहित आएँगे',decline:'आ नहीं पाएँगे',guestCount:'मेहमानों की संख्या',whichEvents:'आप किन समारोहों में शामिल होंगे?',eventHaldi:'हल्दी',eventMehendi:'मेहंदी एवं संगीत',eventWedding:'शादी',eventReception:'स्वागत समारोह',guestMessage:'जोड़े के लिए संदेश (वैकल्पिक)',submitRsvp:'जवाब भेजें',formNote:'यह नमूना आपका जवाब WhatsApp में तैयार करता है। सीधे भेजने के लिए app.js में जोड़े का नंबर जोड़ें।',
    closingTitle:'आपके साथ जश्न मनाने का बेसब्री से इंतज़ार है।',closingText:'सप्रेम, आरव एवं मीरा और उनके परिवार।',footerText:'प्यार और थोड़े से जादू के साथ बनाया गया'
  }
};

let currentLanguage = 'en';
const languageToggle = document.getElementById('languageToggle');
function setLanguage(language) {
  currentLanguage = language;
  document.documentElement.lang = language === 'hi' ? 'hi' : 'en';
  document.body.classList.toggle('hindi-mode', language === 'hi');
  document.querySelectorAll('[data-i18n]').forEach((element) => {
    const value = translations[language][element.dataset.i18n];
    if (value !== undefined) element.innerHTML = value;
  });
  languageToggle.textContent = language === 'en' ? 'हिंदी' : 'English';
  languageToggle.setAttribute('aria-label', language === 'en' ? 'Switch to Hindi' : 'Switch to English');
  document.title = language === 'en' ? 'Aarav & Meera — Wedding Celebration' : 'आरव एवं मीरा — शुभ विवाह';
}
languageToggle.addEventListener('click', () => setLanguage(currentLanguage === 'en' ? 'hi' : 'en'));

const menuToggle = document.getElementById('menuToggle');
const siteNav = document.getElementById('siteNav');
menuToggle.addEventListener('click', () => {
  const isOpen = siteNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
});
siteNav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  siteNav.classList.remove('open'); menuToggle.setAttribute('aria-expanded', 'false');
}));

const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => { if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); } });
  }, { threshold: 0.14 });
  revealItems.forEach((item) => revealObserver.observe(item));
} else revealItems.forEach((item) => item.classList.add('is-visible'));

function updateCountdown() {
  const target = new Date(WEDDING.ceremonyDate).getTime();
  const now = Date.now();
  let remaining = Math.max(0, target - now);
  const days = Math.floor(remaining / 86400000); remaining %= 86400000;
  const hours = Math.floor(remaining / 3600000); remaining %= 3600000;
  const minutes = Math.floor(remaining / 60000); remaining %= 60000;
  const seconds = Math.floor(remaining / 1000);
  document.getElementById('days').textContent = String(days).padStart(3, '0');
  document.getElementById('hours').textContent = String(hours).padStart(2, '0');
  document.getElementById('minutes').textContent = String(minutes).padStart(2, '0');
  document.getElementById('seconds').textContent = String(seconds).padStart(2, '0');
}
updateCountdown();
window.setInterval(updateCountdown, 1000);

const rsvpForm = document.getElementById('rsvpForm');
rsvpForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const name = document.getElementById('guestName').value.trim();
  const phone = document.getElementById('guestPhone').value.trim();
  const attendance = rsvpForm.querySelector('input[name="attendance"]:checked')?.value || 'No response';
  const guestCount = document.getElementById('guestCount').value;
  const events = [...rsvpForm.querySelectorAll('input[name="eventChoice"]:checked')].map((input) => input.value);
  const note = document.getElementById('guestMessage').value.trim();
  const message = [
    `Wedding RSVP — ${WEDDING.couple}`,
    `Name: ${name}`,
    `Mobile: ${phone || 'Not provided'}`,
    `Response: ${attendance}`,
    `Guests: ${guestCount}`,
    `Events: ${events.length ? events.join(', ') : 'Not selected'}`,
    note ? `Message: ${note}` : ''
  ].filter(Boolean).join('\n');
  const recipient = WEDDING.whatsappNumber.replace(/\D/g, '');
  const url = `https://wa.me/${recipient}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
});

setLanguage('en');
